# strawberry-finder > 2024-02-08 6:12pm
https://universe.roboflow.com/lans-space/strawberry-finder

Provided by a Roboflow user
License: CC BY 4.0

